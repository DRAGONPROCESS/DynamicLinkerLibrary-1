#include "dll.h"

extern "C"{
DLLS wchar_t* GetIntVar(const wchar_t *text){
	static wchar_t ret[10]={0};
	wcscat(ret,text);
	wcscat(ret,L"hmm");
	return ret;
}
DLLS char* GetIntVars(char *text){
	static char ret[10]={0};
	strcat(ret,text);
	strcat(ret,"char!");
	return ret;
}
}
