#define DLLS __declspec(dllexport)
#include <string.h>
#include <wchar.h>
