import ctypes

mydll = ctypes.WinDLL('C:\\Users\\sw031\\OneDrive\\바탕 화면\\blogs\\blog-dll.dll')
GetIntVarP = mydll['GetIntVar']
GetIntVarP.argtypes = (ctypes.c_wchar_p,)
GetIntVarP.restype = ctypes.c_wchar_p

GetIntVarPs = mydll['GetIntVars']
GetIntVarPs.argtypes = (ctypes.c_char_p,)
GetIntVarPs.restype = ctypes.c_char_p

#string = str(GetIntVarP("d"))
#print(string)

byte = str(input())
char = GetIntVarPs(bytes(byte,encoding="utf-8"))
print(char)
